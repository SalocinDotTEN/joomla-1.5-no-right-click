<?php
/**
 * Helper class for the slient no right click 1.5 native module
 * 
 * @package    Silent.No.Right.Click.1.5
 * @subpackage Modules
 * @link http://www.salocinten.info
 * @license        GNU/GPL, see LICENSE.php
 * mod_helloworld is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
class modSilentNoRightClick
{
    /**
     * Retrieves the script to embed
     *
     * @param array $params An object containing the module parameters
     * @access public
     */    
    function getNoRightClick( $params )
    {
        return '<script language=JavaScript>
<!--

//Disable right click script III- By Renigade (renigade@mediaone.net)
//For full source code, visit http://www.dynamicdrive.com

var message="";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}

document.oncontextmenu=new Function("return false")
// --> 
</script>';
    }
}
?>