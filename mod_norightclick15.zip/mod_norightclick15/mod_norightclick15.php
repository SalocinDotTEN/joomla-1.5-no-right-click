<?php
/**
* @version 1.0
* @package NoRightClick
* @copyright Copyright Salocin.TEN
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
*/
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Include the syndicate functions only once
require_once( dirname(__FILE__).DS.'helper.php' );

$norightclick = modSilentNoRightClick::getNoRightClick( $params );
require( JModuleHelper::getLayoutPath( 'mod_norightclick15' ) );
?>